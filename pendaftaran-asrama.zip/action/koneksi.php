<?php 
$koneksi = mysqli_connect('localhost', 'root', 'root', 'pendaftaran_asrama');
date_default_timezone_set('Asia/Jakarta');
?>